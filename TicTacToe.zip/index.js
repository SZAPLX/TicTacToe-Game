// javascript
const game = document.getElementById("game")
let spaces = [null, null, null, null, null, null, null, null, null]
const O_TEXT = "O"
const X_TEXT = "X"
let currentPlayer = X_TEXT
let turns = 0
let gameEnd = false
const winningCombinations = [
	[0, 1, 2],
	[3, 4, 5],
	[6, 7, 8],
	[0, 3, 6],
	[1, 4, 7],
	[2, 5, 8],
	[0, 4, 8],
	[2, 4, 6]
]

let message = document.getElementById("message")

const restartGameBtn = document.getElementById("restart-game-btn")
const restartGameBtnO = document.getElementById("restart-game-btn-o")

const rowOne = document.getElementById("row-one")
const rowTwo = document.getElementById("row-two")
const rowThree = document.getElementById("row-three")

let square = document.querySelectorAll(".square")

const squareOne = document.getElementById("0")
const squareTwo = document.getElementById("1")
const squareThree = document.getElementById("2")
const squareFour = document.getElementById("3")
const squareFive = document.getElementById("4")
const squareSix = document.getElementById("5")
const squareSeven = document.getElementById("6")
const squareEight = document.getElementById("7")
const squareNine = document.getElementById("8")

square.forEach(item => {
  item.addEventListener('click', event => {
	  const id = event.target.id
	  if (!spaces[id]) {
		  spaces[id] = currentPlayer
          event.target.innerHTML = currentPlayer
          if (playerHasWon()) {
              message.innerHTML = `${currentPlayer} Has won!`
              gameEnd = true
              return
          }
          currentPlayer = currentPlayer === O_TEXT ? X_TEXT : O_TEXT
	  }
  })
})

function playerHasWon() {
    if (spaces[0] === currentPlayer) {
        if (spaces[1] === currentPlayer && spaces[2] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        } else if (spaces[4] === currentPlayer && spaces[8] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        } else if (spaces[3] === currentPlayer && spaces[6] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        }
    } if (spaces [1] === currentPlayer) {
        if (spaces[4] === currentPlayer && spaces[7] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        } 
    } if (spaces[2] === currentPlayer) {
        if (spaces[5] === currentPlayer && spaces[8]) {
            message.innerHTML = `${currentPlayer} has won!`
        } else if (spaces[4] === currentPlayer && spaces[6] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        }
    } if (spaces[3] === currentPlayer) {
        if (spaces[4] === currentPlayer && spaces[5] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        } 
    } if (spaces[6] === currentPlayer) {
        if (spaces[7] === currentPlayer && spaces[8] === currentPlayer) {
            message.innerHTML = `${currentPlayer} has won!`
        }
    }
}

restartGameBtn.addEventListener("click", function() {
    spaces = [null, null, null, null, null, null, null, null, null]
    gameEnd = false
    message.innerHTML = ``
    for (i = 0; i < square.length; i++) {
        square[i].innerHTML = ``
    }
    currentPlayer = X_TEXT
})

restartGameBtnO.addEventListener("click", function() {
    spaces = [null, null, null, null, null, null, null, null, null]
    gameEnd = false
    message.innerHTML = ``
    for (i = 0; i < square.length; i++) {
        square[i].innerHTML = ``
    }
    currentPlayer = O_TEXT
})
